# MIA GAMES
http://miagames.wz.cz/project/games  
stránka fiktivní herní firmy, která ukazuje svoje hry z databáze  
## Technologies used
- PHP, Javascript, HTML, CSS, SASS, SQL, JSON
