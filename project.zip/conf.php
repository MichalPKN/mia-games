<?php

define("URL", "localhost");
define("URL_DIR", "/project/");
define("APP_DIR", "app/");
define("DATA_DIR", "data/pages/");
define("TMPLT_DIR", "templates/");